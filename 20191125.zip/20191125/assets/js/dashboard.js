function Validation(){
	alert("enter input values");
	var searchField = document.getElementById('inputValidation').value;
	if(searchField == " "){
		alert("ok");
	}
}