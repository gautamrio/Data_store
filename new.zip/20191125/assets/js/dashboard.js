function validation(){
	if(document.getElementById('inputValidation').value == ""){
		alert('Enter value input');
	}
	else{
		alert(document.getElementById('inputValidation').value);
	}
}

